/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50625
Source Host           : localhost:3306
Source Database       : db_user

Target Server Type    : MYSQL
Target Server Version : 50625
File Encoding         : 65001

Date: 2017-12-01 13:10:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tb_user
-- ----------------------------
DROP TABLE IF EXISTS `tb_user`;
CREATE TABLE `tb_user` (
  `id` bigint(16) NOT NULL COMMENT 'ID',
  `username` varchar(50) NOT NULL COMMENT '用户名',
  `age` int(11) NOT NULL COMMENT '年龄',
  `create_time` datetime NOT NULL COMMENT '创建时间',
  `last_modify_time` datetime DEFAULT NULL COMMENT '更新时间',
  `version` int(11) DEFAULT NULL COMMENT '版本号',
  `create_account_id` bigint(16) DEFAULT NULL COMMENT '创建人id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_user
-- ----------------------------
INSERT INTO `tb_user` VALUES ('1', '张三', '18', '2017-11-26 21:01:05', null, null, null);
INSERT INTO `tb_user` VALUES ('2', '李四', '20', '2017-11-26 21:01:05', null, null, null);
INSERT INTO `tb_user` VALUES ('3', '王五', '19', '2017-11-26 21:01:05', null, null, null);
INSERT INTO `tb_user` VALUES ('4', '李九1', '25', '2017-11-27 10:36:37', null, null, null);
INSERT INTO `tb_user` VALUES ('5', 'testq', '30', '2017-11-29 16:15:03', null, null, null);
INSERT INTO `tb_user` VALUES ('2460713301411840', 'string', '40', '2017-11-29 16:22:57', null, null, null);
INSERT INTO `tb_user` VALUES ('2460725750810624', '唐玲', '20', '2017-11-29 16:35:45', null, '0', '2460713301411840');
INSERT INTO `tb_user` VALUES ('2462204932605952', '李天一', '23', '2017-11-30 17:40:04', null, '0', null);
