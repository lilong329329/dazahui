package com.dzjt.cbs.data.collection.service.impl;

import java.io.File;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONArray;
import com.dzjt.cbs.base.constant.Constant;
import com.dzjt.cbs.base.constant.DataCollectionConfig;
import com.dzjt.cbs.base.constant.SFTPConfigs;
import com.dzjt.cbs.base.exception.DzjtException;
import com.dzjt.cbs.base.util.DESUtils;
import com.dzjt.cbs.base.util.DateUtils;
import com.dzjt.cbs.base.util.EncryptZip;
import com.dzjt.cbs.base.util.FileUtils;
import com.dzjt.cbs.base.util.JsonUtils;
import com.dzjt.cbs.base.util.SFTPUtils;
import com.dzjt.cbs.base.util.ZipUtil;
import com.dzjt.cbs.data.collection.domain.Area;
import com.dzjt.cbs.data.collection.domain.Owner;
import com.dzjt.cbs.data.collection.domain.Supplier;
import com.dzjt.cbs.data.collection.domain.Vehicle;
import com.dzjt.cbs.data.collection.domain.VehicleAsset;
import com.dzjt.cbs.data.collection.domain.VehicleModel;
import com.dzjt.cbs.data.collection.infrastructure.AreaMapper;
import com.dzjt.cbs.data.collection.infrastructure.OwnerMapper;
import com.dzjt.cbs.data.collection.infrastructure.SupplierMapper;
import com.dzjt.cbs.data.collection.infrastructure.VehicleAssetMapper;
import com.dzjt.cbs.data.collection.infrastructure.VehicleMapper;
import com.dzjt.cbs.data.collection.infrastructure.VehicleModelMapper;
import com.dzjt.cbs.data.collection.service.CgDataMigrationService;
import com.github.pagehelper.PageHelper;

@Service
public class CgDataMigrationServiceImpl implements CgDataMigrationService {

	private Logger logger = LoggerFactory.getLogger(CgDataMigrationServiceImpl.class);
	@Autowired
	private DataCollectionConfig dzcgConfigs;
	@Autowired
	private SFTPConfigs sftpConfigs;

	@Autowired
	private AreaMapper areaMapper; // 1
	@Autowired
	private OwnerMapper ownerMapper;// 2
	@Autowired
	private SupplierMapper supplierMapper;// 3
	@Autowired
	private VehicleAssetMapper vehicleAssetMapper;// 4
	@Autowired
	private VehicleMapper vehicleMapper;// 5
	@Autowired
	private VehicleModelMapper vehicleModelMapper;// 6

	@Override
	public boolean cgDataMigrationALL() throws DzjtException {
		boolean status = false;
		JsonUtils<Area> areajsons = new JsonUtils<Area>();
		JsonUtils<Owner> ownerjsons = new JsonUtils<Owner>();
		JsonUtils<Supplier> supplierjsons = new JsonUtils<Supplier>();
		JsonUtils<VehicleAsset> vehicleAssetjsons = new JsonUtils<VehicleAsset>();
		JsonUtils<Vehicle> vehiclejsons = new JsonUtils<Vehicle>();
		JsonUtils<VehicleModel> vehicleModeljsons = new JsonUtils<VehicleModel>();
		Date startDate = new Date();
		String path = dzcgConfigs.getBasepath();
		String upLoadPath = dzcgConfigs.getUploadpath();
		File file = new File(path);
			boolean result = FileUtils.findByFilepath(file);
	        if(!result) {
	        	
	        	FileUtils.createDir(path);
	        }
		String key = dzcgConfigs.getKey();
		String dirName = DateUtils.getLastDates();
		String destDirName = path + File.separator + dirName+Constant.FILENAME_ALL;
		FileUtils.createDir(destDirName);
		int areaCount = areaMapper.findAllByCount();
		int ownerCount = ownerMapper.findAllByCount();
		int supplierCount = supplierMapper.findAllByCount();
		int vehicleAssetCount = vehicleAssetMapper.findAllByCount();
		int vehicleCount = vehicleMapper.findAllByCount();
		int vehicleModelCount = vehicleModelMapper.findAllByCount();
		String fileSize = dzcgConfigs.getFilesize();
		int size = Integer.parseInt(fileSize);
	
		int count1 = getTxtCount(areaCount, size);
		int count2 = getTxtCount(ownerCount, size);
		int count3 = getTxtCount(supplierCount, size);
		int count4 = getTxtCount(vehicleAssetCount, size);
		int count5 = getTxtCount(vehicleCount, size);
		int count6 = getTxtCount(vehicleModelCount, size);
		for (int j = 1; j <= count1; j++) {
			// 设置分页信息，分别是当前页数和每页显示的总记录数
			PageHelper.startPage(j, size);
			List<Area> areas = areaMapper.findAll();

			int countNums = areaMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<Area> pageData = new com.dzjt.cbs.base.util.PageBean(j, size, countNums);
			pageData.setItems(areas);
			JSONArray jsons = new JSONArray();
			for (Area c : pageData.getItems()) {
				String json = areajsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName +File.separator+"Area" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + File.separator + "Area" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName + File.separator + "Area" + count1 + Constant.SUFFIX_TXT + "失败");
				throw new DzjtException(
						"errorMessage:  " + destDirName + File.separator + "Area" + count1 + Constant.SUFFIX_TXT + "失败");
			}

		}
		for (int j = 1; j <= count2; j++) {
			PageHelper.startPage(j, size);
			List<Owner> owners = ownerMapper.findAll();
			int countNums = ownerMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<Owner> pageData = new com.dzjt.cbs.base.util.PageBean(j, size, countNums);
			pageData.setItems(owners);

			JSONArray jsons = new JSONArray();
			for (Owner c : pageData.getItems()) {
				String json = ownerjsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName +File.separator+ "Owner" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + File.separator + "Owner" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName + File.separator + "Owner" + count1 + Constant.SUFFIX_TXT + "失败");
				throw new DzjtException(
						"errorMessage:  " + destDirName + File.separator + "Owner" + count1 + Constant.SUFFIX_TXT + "失败");
			}

		}

		for (int j = 1; j <= count3; j++) {
			PageHelper.startPage(j, size);
			List<Supplier> suppliers = supplierMapper.findAll();
			int countNums = supplierMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<Supplier> pageData = new com.dzjt.cbs.base.util.PageBean(j, size,
					countNums);
			pageData.setItems(suppliers);

			JSONArray jsons = new JSONArray();
			for (Supplier c : pageData.getItems()) {
				String json = supplierjsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName + File.separator +"Supplier" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + File.separator + "Supplier" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName + File.separator + "Supplier" + count1 + Constant.SUFFIX_TXT + "失败");
				throw new DzjtException(
						"errorMessage:  " + destDirName + File.separator + "Supplier" + count1 + Constant.SUFFIX_TXT + "失败");
			}

		}

		for (int j = 1; j <= count4; j++) {
			PageHelper.startPage(j, size);
			List<VehicleAsset> vehicleAssets = vehicleAssetMapper.findAll();
			int countNums = vehicleAssetMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<VehicleAsset> pageData = new com.dzjt.cbs.base.util.PageBean(j, size,
					countNums);
			pageData.setItems(vehicleAssets);

			JSONArray jsons = new JSONArray();
			for (VehicleAsset c : pageData.getItems()) {
				String json = vehicleAssetjsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName + File.separator+"VehicleAsset" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + "/" + "VehicleAsset" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName + File.separator + "VehicleAsset" + count1 + Constant.SUFFIX_TXT + "失败");
				 throw new DzjtException("errorMessage:  "+destDirName+File.separator+"WorkType"+count1+Constant.SUFFIX_TXT+"失败");
				 
			}

		}

		for (int j = 1; j <= count5; j++) {
			PageHelper.startPage(j, size);
			List<Vehicle> vehicles = vehicleMapper.findAll();
			int countNums = vehicleMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<Vehicle> pageData = new com.dzjt.cbs.base.util.PageBean(j, size, countNums);
			pageData.setItems(vehicles);

			JSONArray jsons = new JSONArray();
			for (Vehicle c : pageData.getItems()) {
				String json = vehiclejsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName +File.separator+ "Vehicle" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + File.separator + "Vehicle" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName +File.separator + "Vehicle" + count1 + Constant.SUFFIX_TXT + "失败");
				 throw new DzjtException("errorMessage:  "+destDirName+File.separator+"Motorcade"+count1+Constant.SUFFIX_TXT+"失败");
			}

		}

		for (int j = 1; j <= count6; j++) {
			PageHelper.startPage(j, size);
			List<VehicleModel> vehicleModels = vehicleModelMapper.findAll();
			int countNums = vehicleModelMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<VehicleModel> pageData = new com.dzjt.cbs.base.util.PageBean(j, size,
					countNums);
			pageData.setItems(vehicleModels);

			JSONArray jsons = new JSONArray();
			for (VehicleModel c : pageData.getItems()) {
				String json = vehicleModeljsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName + File.separator+"VehicleModel" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + File.separator + "VehicleModel" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName + File.separator + "VehicleModel" + count1 + Constant.SUFFIX_TXT + "失败");
				 throw new DzjtException("errorMessage:  "+destDirName+File.separator+"Motorcade"+count1+Constant.SUFFIX_TXT+"失败");
			}

		}

		String dst = dzcgConfigs.getUploadpath();
		Map<String, String> sftpDetails = new HashMap<String, String>();

		sftpDetails.put("SFTP_REQ_HOST", sftpConfigs.getIp());
		sftpDetails.put("SFTP_REQ_USERNAME", sftpConfigs.getUsername());
		sftpDetails.put("SFTP_REQ_PASSWORD", sftpConfigs.getPassword());
		sftpDetails.put("SFTP_REQ_PORT", sftpConfigs.getPort());
		sftpDetails.put("SFTP_REQ_PRIVATE_KEY", sftpConfigs.getPrivatekey());

		
		EncryptZip td = new EncryptZip(); 
        try {
        	
        td.zip(destDirName, key);
        SFTPUtils.uploadFile(destDirName + Constant.SUFFIX_ZIP, dst, sftpDetails);
    	logger.info("SFTP Upload File Success! Current Date is :" + DateUtils.getCurrentDateTime());
		status = true;

		} catch (Exception e) {
			logger.info("SFTP Upload File Failed! Current Date is :" + DateUtils.getCurrentDateTime());
			return false;
		}
		 FileUtils.delFolder(destDirName);      
		 logger.info("Local delete File Success! Current Date is :" + DateUtils.getCurrentDateTime());

			Date endDate = new Date();
			String timeDiff = DateUtils.getTimeDifference(startDate, endDate);

			logger.info("本次执行安全系统数据迁移花费时间：" + timeDiff);

			return status;
	}

	

	// 按月进行查找
	@Override
	public boolean cgFindDataByMonth() throws DzjtException {
		boolean status = false;
		JsonUtils<Vehicle> vehiclejsons = new JsonUtils<Vehicle>();
		Date startDate = new Date();
		String path = dzcgConfigs.getBasepath();
		
		File file = new File(path);
		boolean result = FileUtils.findByFilepath(file);
        if(!result) {
        	FileUtils.createDir(path);
        }
		
		String key = dzcgConfigs.getKey();
		String dirName = DateUtils.getLastDates();
		String destDirName = path + File.separator + dirName+Constant.FILENAME_MONTH;
		String fileSize = dzcgConfigs.getFilesize();
		int size = Integer.parseInt(fileSize);
		FileUtils.createDir(destDirName);
	     String time = DateUtils.getLastDate1();
		int vehicleCount = vehicleMapper.findAllByCount();	
		int count5 = getTxtCount(vehicleCount, size);
		for (int j = 1; j <= count5; j++) {
			// 设置分页信息，分别是当前页数和每页显示的总记录数
			PageHelper.startPage(j, size);
			List<Vehicle> vehicles = vehicleMapper.findAll();

			int countNums = vehicleMapper.findAllByCount();// 总记录数
			com.dzjt.cbs.base.util.PageBean<Vehicle> pageData = new com.dzjt.cbs.base.util.PageBean(j, size, countNums);
			pageData.setItems(vehicles);
			JSONArray jsons = new JSONArray();
			for (Vehicle c : pageData.getItems()) {
				String json = vehiclejsons.toJSon(c);
				jsons.add(json);

			}
			FileUtils.createFile(destDirName + File.separator+"Vehicle" + j + Constant.SUFFIX_TXT);
			boolean flag = FileUtils.writeTxtFile(jsons + "", destDirName + File.separator + "Vehicle" + j + Constant.SUFFIX_TXT);
			if (!flag ) {
				logger.info(destDirName + File.separator + "Vehicle" + count5 + Constant.SUFFIX_TXT + "失败");
				throw new DzjtException("errorMessage:  "+destDirName+File.separator+"Vehicle"+Constant.SUFFIX_TXT+"失败");
			}

		}
		String dst = dzcgConfigs.getUploadpath();
		Map<String, String> sftpDetails = new HashMap<String, String>();

		sftpDetails.put("SFTP_REQ_HOST", sftpConfigs.getIp());
		sftpDetails.put("SFTP_REQ_USERNAME", sftpConfigs.getUsername());
		sftpDetails.put("SFTP_REQ_PASSWORD", sftpConfigs.getPassword());
		sftpDetails.put("SFTP_REQ_PORT", sftpConfigs.getPort());
		sftpDetails.put("SFTP_REQ_PRIVATE_KEY", sftpConfigs.getPrivatekey());

		EncryptZip td = new EncryptZip(); 
        try {
        td.zip(destDirName, key);
        SFTPUtils.uploadFile(destDirName + Constant.SUFFIX_ZIP, dst, sftpDetails);
    	logger.info("SFTP Upload File Success! Current Date is :" + DateUtils.getCurrentDateTime());
		status = true;
		} catch (Exception e) {
			logger.info("SFTP Upload File Failed! Current Date is :" + DateUtils.getCurrentDateTime());
			return false;
		
		}
        FileUtils.delFolder(destDirName);
	        Date endDate = new Date();
	        String timeDiff = DateUtils.getTimeDifference(startDate,endDate);
	        
	        logger.info("本次执行销卡系统数据迁移花费时间：" + timeDiff);
	        
	        
	        return status;
	}

	public static int getTxtCount(int a, int b) {
		int num = a / b;
		if (a % b != 0) {
			num++;
		}
		return num;
	}

}
