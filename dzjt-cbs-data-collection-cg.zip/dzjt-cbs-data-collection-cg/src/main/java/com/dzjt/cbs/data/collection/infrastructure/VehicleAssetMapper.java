package com.dzjt.cbs.data.collection.infrastructure;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.dzjt.cbs.data.collection.domain.VehicleAsset;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午3:38:27
 */
@Mapper
public interface VehicleAssetMapper {
	@Select("SELECT * FROM vms.VehicleAsset")
	@Results({@Result(column="Id", property="id"),
		@Result(column="Version", property="version"), 
		@Result(column="Enabled", property="enabled"), 
		@Result(column="PurchasePrice", property="purchasePrice"), 
		@Result(column="PurchaseTax", property="purchaseTax"), 
		@Result(column="LicensePrice", property="licensePrice"), 
		@Result(column="LicenseOtherPrice", property="licenseOtherPrice"), 
		@Result(column="UpholsterPrice", property="upholsterPrice"), 		
		@Result(column="TotalPrice", property="totalPrice"), 
		@Result(column="RemainPrice", property="remainPrice"), 
		@Result(column="SecondHandPrice", property="secondHandPrice"), 
		@Result(column="VehicleId", property="vehicleId")})
	List<VehicleAsset> findAll();

	@Select("SELECT COUNT(1) FROM vms.VehicleAsset")
	int findAllByCount();
}
