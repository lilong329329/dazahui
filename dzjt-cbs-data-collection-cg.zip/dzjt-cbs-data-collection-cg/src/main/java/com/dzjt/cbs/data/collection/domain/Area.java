package com.dzjt.cbs.data.collection.domain;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午1:01:55
 */
public class Area {
	private Integer id;//
	private Integer version;//
	private String name;//
	private String theValue;//
	private String levelCode;//
	private Integer parentId;//
	private Integer position;//
	private Integer enabled;//
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTheValue() {
		return theValue;
	}
	public void setTheValue(String theValue) {
		this.theValue = theValue;
	}
	public String getLevelCode() {
		return levelCode;
	}
	public void setLevelCode(String levelCode) {
		this.levelCode = levelCode;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getPosition() {
		return position;
	}
	public void setPosition(Integer position) {
		this.position = position;
	}
	public Integer getEnabled() {
		return enabled;
	}
	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}

	
}
