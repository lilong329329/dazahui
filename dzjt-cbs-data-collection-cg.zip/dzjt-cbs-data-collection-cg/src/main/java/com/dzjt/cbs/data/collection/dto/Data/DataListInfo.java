package com.dzjt.cbs.data.collection.dto.Data;

import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel("DataListInfo")
public class DataListInfo {
	List<DataInfo> list;
	@ApiModelProperty(value = "list")
	public List<DataInfo> getList() {
		return list;
	}

	public void setList(List<DataInfo> list) {
		this.list = list;
	}
	
}
