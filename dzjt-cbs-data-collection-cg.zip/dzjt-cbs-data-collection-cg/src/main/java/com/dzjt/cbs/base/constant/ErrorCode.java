package com.dzjt.cbs.base.constant;

/**
 * <pre>
 * Error code explain example:
 * ************************************************
 * project short name-module code-function code-error code:
 * 0100100101
 * ************************************************
 * project code:
 *  dzjt-cbs-accountandauthority-management:01;
 *  dzjt-cbs-authentication-management:02;
 *  dzjt-cbs-dashboardmetrics-management:03;
 *  dzjt-cbs-feedback-management:04;
 *  dzjt-cbs-messageandnotice-management:05;
 *  dzjt-cbs-profile-management:06;
 *  dzjt-cbs-reporting-management:07;
 *  dzjt-cbs-route-management:08;
 *  dzjt-cbs-routeandshuttlemeta-management:09;
 *  dzjt-cbs-shuttle-management:10;
 *  dzjt-cbs-wechat-management:11;
 * ************************************************
 * dzjt-cbs-wechat-management module code
 *  User:001
 * ************************************************
 * dzjt-cbs-wechat-management function code
 *  Add:001
 *  Get:002
 *  Update:003
 *  Delete:004
 * ************************************************
 *  dzjt-cbs-wechat-management error code
 *  Invalid Param:01
 *  Entity Not Exists:02
 *  Biz Exception:03
 *  Feign Failed:05
 * </pre>
 */
public class ErrorCode {
	public static final String SYSTEMERRORCODE = "500";
	public static final String SYSTEM_STATUSCONTEXT = "System";

	// USER ADD INVALIDPARAM CODE
	public static final String USER_ADD_FAIL_CODE = "11001001";
	public static final String USER_ADD_FAIL_MESSAGE = "add user failed";
	public static final String USER_ADD_STATUSCONTEXT = "api/dzjtcbs/v1/user";

	// USER ADD INVALIDPARAM MESSAGE
	public static final String USER_ADD_NOT_EMPTY_CODE = "1100100101";
	public static final String USER_ADD_NAME_NOT_EMPTY_MESSAGE = "user name is not empty";
	public static final String USER_ADD_AGE_NOT_EMPTY_MESSAGE = "user age is not empty ";

	
	// USER UPDATE INVALIDPARAM CODE
	public static final String USER_UPDATE_FAIL_CODE = "11001003";
	public static final String USER_UPDATE_FAIL_MESSAGE = "update user failed";
	public static final String USER_UPDATE_STATUSCONTEXT = "api/dzjtcbs/v1/user";
	
	// USER UPDATE INVALIDPARAM MESSAGE
	public static final String USER_UPDATE_ID_NOT_EMPTY_MESSAGE = "user id is not empty";
	public static final String USER_UPDATE_NAME_NOT_EMPTY_MESSAGE = "user name is not empty";
	public static final String USER_UPDATE_AGE_NOT_EMPTY_MESSAGE = "user age is not empty ";

	// USER DEL FAIL CODE AND MESSAGE
	public static final String USER_DEL_FAIL_CODE = "11001004";
	public static final String USER_DEL_FAIL_MESSAGE = "del user failed";
	public static final String USER_DEL_STATUSCONTEXT = "api/dzjtcbs/v1/user/{id}";

	// public static final String USER_ADD_CREATE_NOTEXISTED_CODE="0400100102";
	// public static final String USER_ADD_CREATE_NOTEXISTED="this trip history has
	// comments";
	//
	// public static final String USER_ADD_LIST_FEIGNE_FAILED_CODE="0400100105";
	// public static final String USER_ADD_LIST_FEIGNE_FAILED=" invoke get trip
	// history failed, please try again later";
	// public static final String
	// USER_ADD_LIST_STATUSCONTEXT="api/NanjingShuttle/v1/comment";
}
