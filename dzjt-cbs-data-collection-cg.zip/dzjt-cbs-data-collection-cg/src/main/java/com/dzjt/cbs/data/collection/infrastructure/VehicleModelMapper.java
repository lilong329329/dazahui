package com.dzjt.cbs.data.collection.infrastructure;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.dzjt.cbs.data.collection.domain.VehicleModel;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午3:50:16
 */
@Mapper
public interface VehicleModelMapper {
	@Select("SELECT * FROM vms.VehicleModel")
	@Results({@Result(column="Id", property="id"),
		@Result(column="Version", property="version"), 
		@Result(column="Enabled", property="enabled"), 
		@Result(column="ModelNo", property="modelNo"), 
		@Result(column="EngineModelNo", property="engineModelNo"), 
		@Result(column="Capacity", property="capacity"), 
		@Result(column="Power", property="power"), 
		@Result(column="TreadFront", property="treadFront"), 		
		@Result(column="TreadRear", property="treadRear"), 
		@Result(column="WheelQuantity", property="wheelQuantity"), 
		@Result(column="WheelParam", property="wheelParam"), 
		@Result(column="SpringLamination", property="springLamination"), 
		@Result(column="WheelBase1", property="wheelBase1"), 
		@Result(column="WheelBase2", property="wheelBase2"), 
		@Result(column="WheelBase3", property="wheelBase3"), 
		@Result(column="AxleQuantity", property="axleQuantity"), 
		@Result(column="OutLength", property="outLength"), 
		
		@Result(column="OutWidth", property="outWidth"), 
		@Result(column="OutHeight", property="outHeight"), 
		@Result(column="ContainerLength", property="containerLength"), 
		@Result(column="ContainerWidth", property="containerWidth"), 
		@Result(column="ContainerHeight", property="containerHeight"), 
		@Result(column="TotalMass", property="totalMass"), 
		@Result(column="AssessMass", property="assessMass"), 		
		@Result(column="AssessPassenger", property="assessPassenger"), 
		@Result(column="TractionMass", property="tractionMass"), 
		@Result(column="CabPassenger", property="cabPassenger"), 
		@Result(column="ManufactureLocation", property="manufactureLocation"), 
		@Result(column="DoorQuantity", property="doorQuantity"), 
		@Result(column="GearQuantity", property="gearQuantity"), 
		@Result(column="Acceleration", property="acceleration"), 
		@Result(column="Speed", property="speed"), 
		@Result(column="TurningRadius", property="turningRadius"),
		
		@Result(column="RoadClearance", property="roadClearance"), 
		@Result(column="Gradient", property="gradient"), 
		@Result(column="FuelEconomy", property="fuelEconomy"), 		
		@Result(column="FuelEconomyMiit", property="fuelEconomyMiit"), 
		@Result(column="Torque", property="torque"), 
		@Result(column="CompressionRatio", property="compressionRatio"), 
		@Result(column="ManufacturerId", property="manufacturerId"), 
		@Result(column="GasTypeId", property="gasTypeId"), 
		@Result(column="VehicleBrandId", property="vehicleBrandId"), 
		@Result(column="VehicleTypeId", property="vehicleTypeId"), 
		@Result(column="WheelDriveId", property="wheelDriveId"), 
		@Result(column="BreakModeId", property="breakModeId"),
		
		@Result(column="TurnModeId", property="turnModeId"), 
		@Result(column="DrivePositionId", property="drivePositionId"), 
		@Result(column="EnginePositionId", property="enginePositionId"), 		
		@Result(column="VehicleAbbreviationId", property="vehicleAbbreviationId"), 
		@Result(column="ExhaustId", property="exhaustId"), 
		@Result(column="GearBoxTypeId", property="gearBoxTypeId")})
	List<VehicleModel> findAll();

	@Select("SELECT COUNT(1) FROM vms.VehicleModel")
	int findAllByCount();
}
