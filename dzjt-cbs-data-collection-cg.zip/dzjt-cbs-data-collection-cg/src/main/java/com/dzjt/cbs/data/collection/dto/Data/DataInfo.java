package com.dzjt.cbs.data.collection.dto.Data;

import io.swagger.annotations.ApiModel;

@ApiModel("DataInfo")
public class DataInfo {
	private String dictItemDesc;
	private String dictItemValue;
	public String getDictItemDesc() {
		return dictItemDesc;
	}
	public void setDictItemDesc(String dictItemDesc) {
		this.dictItemDesc = dictItemDesc;
	}
	public String getDictItemValue() {
		return dictItemValue;
	}
	public void setDictItemValue(String dictItemValue) {
		this.dictItemValue = dictItemValue;
	}
	
	
	
}
