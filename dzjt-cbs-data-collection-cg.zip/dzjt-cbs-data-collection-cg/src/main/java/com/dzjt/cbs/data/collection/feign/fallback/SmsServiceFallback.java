package com.dzjt.cbs.data.collection.feign.fallback;

import java.util.Map;

import org.springframework.stereotype.Component;

import com.dzjt.cbs.data.collection.domain.sms.SMSEntity;
import com.dzjt.cbs.data.collection.feign.SmsService;

@Component
public class SmsServiceFallback implements SmsService {

	public Map<String, Object> sendSms(SMSEntity smsEntity){
		return null;
	}


}
