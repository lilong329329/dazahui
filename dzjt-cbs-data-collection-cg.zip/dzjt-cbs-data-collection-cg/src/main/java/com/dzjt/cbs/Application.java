package com.dzjt.cbs;

import java.io.File;

import org.mybatis.spring.annotation.MapperScan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;

import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.dzjt.cbs.base.constant.DataCollectionConfig;
import com.dzjt.cbs.base.util.FileUtils;
import com.dzjt.cbs.data.collection.service.CgDataMigrationService;



@EnableTransactionManagement
@EnableFeignClients
@SpringBootApplication
//@EnableDiscoveryClient
@EnableCircuitBreaker
@MapperScan("com.dzjt.cbs.data.collection.infrastructure")
public class Application implements CommandLineRunner{
	
	@Autowired
	private DataCollectionConfig dzcgConfigs;
	
	@Autowired
	private CgDataMigrationService dataMigrationService;
	public static void main(String[] args) {
		
		SpringApplication.run(Application.class, args);
	}

	
	@Override
	public void run(String... args) throws Exception {
		File file = new File(dzcgConfigs.getMarkfile());
		boolean flag = FileUtils.findByFilepath(file);
		if(!flag) {
			dataMigrationService.cgDataMigrationALL();
		}
	}
}
