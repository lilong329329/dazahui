package com.dzjt.cbs.base.constant;

public class BusinessException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public static final String RUN_BATCH_MODEL = "大众运行批处理";
	public static final String MASS_TRAVEL_BATCH_MODEL = "大众出行批处理";
	public static final String VOLKSWAGEN_CAR_BATCH_MODEL = "大众车管批处理";
	public static final String PUBLIC_RENTAL_BATCH_MODEL = "大众出租批处理";
	public static final String MASS_PERSONNEL_BATCH_MODEL = "大众人事批处理";
	public static final String PUBLIC_SECURITY_BATCH_MODEL = "大众安全批处理";
	public static final String MASS_SALES_CARD_BATCH_MODEL = "大众销卡批处理";
	public static final String VOLKSWAGEN_RENTING_BATCH_MODEL = "大众租赁CRM批处理";
	public static final String RENTING_BATCH_MODEL = "大众租赁批处理";
	public static final String FILENAME_ALL = "全量数据包";
	public static final String FILENAME_INCREMENTAL = "增量数据包";
	public static final String NO_DATA = "无数据";
	public static final String READ_ERROR = "读取错误";
	public static final String JSON_ERROR = "Json转换错误";
	public static final String DECOMPRESSION_FAILED = "解密解压失败";
	public static final String BATCH_ADD = "批量插入异常";
	public static final String BATCH_UPDATE = "批量修改异常";
	public static final String INTERFACE_MACHINE_EXCEPTION = "接口机异常";

	
	public static final String SAFE_INTERFACE_MACHINE = "大众安全接口机";
	public static final String VOLKSWAGEN_CAR_INTERFACE_MACHINE = "大众车管接口机";
	public static final String PACKAGEING_FAILED = "打包失败";
	public static final String WRITE_FAILED = "写入失败";
	public static final String UPLOAD_FAILED = "上传失败";
	// USER ADD INVALIDPARAM CODE
	public static final String USER_ADD_FAIL_CODE = "11001001";
	public static final String USER_ADD_FAIL_MESSAGE = "add user failed";
	public static final String USER_ADD_STATUSCONTEXT = "api/dzjtcbs/v1/user";

	// USER ADD INVALIDPARAM MESSAGE
	public static final String USER_ADD_NOT_EMPTY_CODE = "1100100101";
	public static final String USER_ADD_NAME_NOT_EMPTY_MESSAGE = "user name is not empty";
	public static final String USER_ADD_AGE_NOT_EMPTY_MESSAGE = "user age is not empty ";

	
	// USER UPDATE INVALIDPARAM CODE
	public static final String USER_UPDATE_FAIL_CODE = "11001003";
	public static final String USER_UPDATE_FAIL_MESSAGE = "update user failed";
	public static final String USER_UPDATE_STATUSCONTEXT = "api/dzjtcbs/v1/user";	
	
}
