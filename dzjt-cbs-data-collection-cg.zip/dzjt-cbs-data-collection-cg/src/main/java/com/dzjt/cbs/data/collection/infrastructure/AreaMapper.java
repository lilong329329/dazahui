package com.dzjt.cbs.data.collection.infrastructure;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.dzjt.cbs.data.collection.domain.Area;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午1:35:12
 */
@Mapper
public interface AreaMapper {
	@Select("SELECT * FROM vms.Area")
	@Results({@Result(column="Id", property="id"),
		@Result(column="Name", property="name"), 
		@Result(column="TheValue", property="theValue"), 
		@Result(column="LevelCode", property="levelCode"), 
		@Result(column="ParentId", property="parentId"), 
		@Result(column="Position", property="position"), 
		@Result(column="Enabled", property="enabled")})
	List<Area> findAll();

	@Select("SELECT COUNT(*)FROM vms.Area")
	int findAllByCount();

}
