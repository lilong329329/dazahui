package com.dzjt.cbs.base.constant;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix="dzjt.datamigration.file.cg")
public class DataCollectionConfig {
	String basepath;
	String uploadpath;
    String filesize;
    String markfile;
    String key;
    public String getBasepath() {
		return basepath;
	}
	public String getMarkfile() {
		return markfile;
	}
	public void setMarkfile(String markfile) {
		this.markfile = markfile;
	}

	public void setBasepath(String basepath) {
		this.basepath = basepath;
	}
	public String getUploadpath() {
		return uploadpath;
	}
	public void setUploadpath(String uploadpath) {
		this.uploadpath = uploadpath;
	}
	public String getFilesize() {
		return filesize;
	}
	public void setFilesize(String filesize) {
		this.filesize = filesize;
	}
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}

	    
}
