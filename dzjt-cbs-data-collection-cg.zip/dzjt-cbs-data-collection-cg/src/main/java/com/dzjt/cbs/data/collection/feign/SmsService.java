package com.dzjt.cbs.data.collection.feign;
import java.util.Map;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dzjt.cbs.data.collection.config.FooConfiguration;
import com.dzjt.cbs.data.collection.domain.sms.SMSEntity;
import com.dzjt.cbs.data.collection.feign.fallback.SmsServiceFallback;
 

@FeignClient(name = "ump", url = "${sms.url}", configuration = FooConfiguration.class, fallback = SmsServiceFallback.class)
public interface SmsService {

	@RequestMapping(value = "dzjt-ump-service/api/sms/getSMSInterfaceCall", method = RequestMethod.POST, headers = "Accept=*/*")
	public Map<String,Object> sendSms(@RequestBody SMSEntity smsEntity);
}
