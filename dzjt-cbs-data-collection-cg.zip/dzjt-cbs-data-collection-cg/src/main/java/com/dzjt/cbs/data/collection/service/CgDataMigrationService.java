package com.dzjt.cbs.data.collection.service;

import com.dzjt.cbs.base.exception.DzjtException;

public interface CgDataMigrationService {

	/**
	 * 大众出租数据 查询所有数据
	 * @throws DzjtException 
	 */
	boolean cgDataMigrationALL() throws DzjtException;

	/**
	 * 每月取全量数据
	 */
	boolean cgFindDataByMonth() throws DzjtException;

}
