package com.dzjt.cbs.data.collection.domain;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午1:25:49
 */
public class VehicleModel {
	private Integer id;//
	private Integer version;//
	private Integer enabled;//
	private String modelNo;//
	private String engineModelNo;//
	private String capacity;//
	private Integer power;//
	private Integer treadFront;//
	private Integer treadRear;//
	private Integer wheelQuantity;//
	private String wheelParam;//
	private Integer springLamination;//
	private Integer wheelBase1;//
	private Integer wheelBase2;//
	private Integer wheelBase3;//
	private Integer axleQuantity;//
	private Integer outLength;//
	private Integer outWidth;//
	private Integer outHeight;//
	private Integer containerLength;//
	private Integer containerWidth;//
	private Integer containerHeight;//
	private Integer totalMass;//
	private Integer assessMass;//
	private Integer assessPassenger;//
	private Integer tractionMass;//
	private Integer cabPassenger;//
	private Integer manufactureLocation;//
	private Integer doorQuantity;//
	private Integer gearQuantity;//
	private Double acceleration;//
	private Integer speed;//
	private Double turningRadius;//
	private Integer roadClearance;//
	private Integer gradient;//
	private Double fuelEconomy;//
	private Double fuelEconomyMiit;//
	private Double torque;//
	private String compressionRatio;//
	private Integer manufacturerId;//
	private Integer gasTypeId;//
	private Integer vehicleBrandId;//
	private Integer vehicleTypeId;//
	private Integer wheelDriveId;//
	private Integer breakModeId;//
	private Integer turnModeId;//
	private Integer drivePositionId;//
	private Integer enginePositionId;//
	private Integer vehicleAbbreviationId;//
	private Integer exhaustId;//
	private Integer gearBoxTypeId;//
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getEnabled() {
		return enabled;
	}
	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}
	public String getModelNo() {
		return modelNo;
	}
	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}
	public String getEngineModelNo() {
		return engineModelNo;
	}
	public void setEngineModelNo(String engineModelNo) {
		this.engineModelNo = engineModelNo;
	}
	public String getCapacity() {
		return capacity;
	}
	public void setCapacity(String capacity) {
		this.capacity = capacity;
	}
	public Integer getPower() {
		return power;
	}
	public void setPower(Integer power) {
		this.power = power;
	}
	public Integer getTreadFront() {
		return treadFront;
	}
	public void setTreadFront(Integer treadFront) {
		this.treadFront = treadFront;
	}
	public Integer getTreadRear() {
		return treadRear;
	}
	public void setTreadRear(Integer treadRear) {
		this.treadRear = treadRear;
	}
	public Integer getWheelQuantity() {
		return wheelQuantity;
	}
	public void setWheelQuantity(Integer wheelQuantity) {
		this.wheelQuantity = wheelQuantity;
	}
	public String getWheelParam() {
		return wheelParam;
	}
	public void setWheelParam(String wheelParam) {
		this.wheelParam = wheelParam;
	}
	public Integer getSpringLamination() {
		return springLamination;
	}
	public void setSpringLamination(Integer springLamination) {
		this.springLamination = springLamination;
	}
	public Integer getWheelBase1() {
		return wheelBase1;
	}
	public void setWheelBase1(Integer wheelBase1) {
		this.wheelBase1 = wheelBase1;
	}
	public Integer getWheelBase2() {
		return wheelBase2;
	}
	public void setWheelBase2(Integer wheelBase2) {
		this.wheelBase2 = wheelBase2;
	}
	public Integer getWheelBase3() {
		return wheelBase3;
	}
	public void setWheelBase3(Integer wheelBase3) {
		this.wheelBase3 = wheelBase3;
	}
	public Integer getAxleQuantity() {
		return axleQuantity;
	}
	public void setAxleQuantity(Integer axleQuantity) {
		this.axleQuantity = axleQuantity;
	}
	public Integer getOutLength() {
		return outLength;
	}
	public void setOutLength(Integer outLength) {
		this.outLength = outLength;
	}
	public Integer getOutWidth() {
		return outWidth;
	}
	public void setOutWidth(Integer outWidth) {
		this.outWidth = outWidth;
	}
	public Integer getOutHeight() {
		return outHeight;
	}
	public void setOutHeight(Integer outHeight) {
		this.outHeight = outHeight;
	}
	public Integer getContainerLength() {
		return containerLength;
	}
	public void setContainerLength(Integer containerLength) {
		this.containerLength = containerLength;
	}
	public Integer getContainerWidth() {
		return containerWidth;
	}
	public void setContainerWidth(Integer containerWidth) {
		this.containerWidth = containerWidth;
	}
	public Integer getContainerHeight() {
		return containerHeight;
	}
	public void setContainerHeight(Integer containerHeight) {
		this.containerHeight = containerHeight;
	}
	public Integer getTotalMass() {
		return totalMass;
	}
	public void setTotalMass(Integer totalMass) {
		this.totalMass = totalMass;
	}
	public Integer getAssessMass() {
		return assessMass;
	}
	public void setAssessMass(Integer assessMass) {
		this.assessMass = assessMass;
	}
	public Integer getAssessPassenger() {
		return assessPassenger;
	}
	public void setAssessPassenger(Integer assessPassenger) {
		this.assessPassenger = assessPassenger;
	}
	public Integer getTractionMass() {
		return tractionMass;
	}
	public void setTractionMass(Integer tractionMass) {
		this.tractionMass = tractionMass;
	}
	public Integer getCabPassenger() {
		return cabPassenger;
	}
	public void setCabPassenger(Integer cabPassenger) {
		this.cabPassenger = cabPassenger;
	}
	public Integer getManufactureLocation() {
		return manufactureLocation;
	}
	public void setManufactureLocation(Integer manufactureLocation) {
		this.manufactureLocation = manufactureLocation;
	}
	public Integer getDoorQuantity() {
		return doorQuantity;
	}
	public void setDoorQuantity(Integer doorQuantity) {
		this.doorQuantity = doorQuantity;
	}
	public Integer getGearQuantity() {
		return gearQuantity;
	}
	public void setGearQuantity(Integer gearQuantity) {
		this.gearQuantity = gearQuantity;
	}
	public Double getAcceleration() {
		return acceleration;
	}
	public void setAcceleration(Double acceleration) {
		this.acceleration = acceleration;
	}
	public Integer getSpeed() {
		return speed;
	}
	public void setSpeed(Integer speed) {
		this.speed = speed;
	}
	public Double getTurningRadius() {
		return turningRadius;
	}
	public void setTurningRadius(Double turningRadius) {
		this.turningRadius = turningRadius;
	}
	public Integer getRoadClearance() {
		return roadClearance;
	}
	public void setRoadClearance(Integer roadClearance) {
		this.roadClearance = roadClearance;
	}
	public Integer getGradient() {
		return gradient;
	}
	public void setGradient(Integer gradient) {
		this.gradient = gradient;
	}
	public Double getFuelEconomy() {
		return fuelEconomy;
	}
	public void setFuelEconomy(Double fuelEconomy) {
		this.fuelEconomy = fuelEconomy;
	}


	public Double getFuelEconomyMiit() {
		return fuelEconomyMiit;
	}
	public void setFuelEconomyMiit(Double fuelEconomyMiit) {
		this.fuelEconomyMiit = fuelEconomyMiit;
	}
	public Double getTorque() {
		return torque;
	}
	public void setTorque(Double torque) {
		this.torque = torque;
	}
	public String getCompressionRatio() {
		return compressionRatio;
	}
	public void setCompressionRatio(String compressionRatio) {
		this.compressionRatio = compressionRatio;
	}
	public Integer getManufacturerId() {
		return manufacturerId;
	}
	public void setManufacturerId(Integer manufacturerId) {
		this.manufacturerId = manufacturerId;
	}
	public Integer getGasTypeId() {
		return gasTypeId;
	}
	public void setGasTypeId(Integer gasTypeId) {
		this.gasTypeId = gasTypeId;
	}
	public Integer getVehicleBrandId() {
		return vehicleBrandId;
	}
	public void setVehicleBrandId(Integer vehicleBrandId) {
		this.vehicleBrandId = vehicleBrandId;
	}
	public Integer getVehicleTypeId() {
		return vehicleTypeId;
	}
	public void setVehicleTypeId(Integer vehicleTypeId) {
		this.vehicleTypeId = vehicleTypeId;
	}
	public Integer getWheelDriveId() {
		return wheelDriveId;
	}
	public void setWheelDriveId(Integer wheelDriveId) {
		this.wheelDriveId = wheelDriveId;
	}
	public Integer getBreakModeId() {
		return breakModeId;
	}
	public void setBreakModeId(Integer breakModeId) {
		this.breakModeId = breakModeId;
	}
	public Integer getTurnModeId() {
		return turnModeId;
	}
	public void setTurnModeId(Integer turnModeId) {
		this.turnModeId = turnModeId;
	}
	public Integer getDrivePositionId() {
		return drivePositionId;
	}
	public void setDrivePositionId(Integer drivePositionId) {
		this.drivePositionId = drivePositionId;
	}
	public Integer getEnginePositionId() {
		return enginePositionId;
	}
	public void setEnginePositionId(Integer enginePositionId) {
		this.enginePositionId = enginePositionId;
	}
	public Integer getVehicleAbbreviationId() {
		return vehicleAbbreviationId;
	}
	public void setVehicleAbbreviationId(Integer vehicleAbbreviationId) {
		this.vehicleAbbreviationId = vehicleAbbreviationId;
	}
	public Integer getExhaustId() {
		return exhaustId;
	}
	public void setExhaustId(Integer exhaustId) {
		this.exhaustId = exhaustId;
	}
	public Integer getGearBoxTypeId() {
		return gearBoxTypeId;
	}
	public void setGearBoxTypeId(Integer gearBoxTypeId) {
		this.gearBoxTypeId = gearBoxTypeId;
	}

	
}
