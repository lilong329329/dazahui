package com.dzjt.cbs.data.collection.domain.sms;

public class SMSEntity {
	private String date;//异常日期
	private String model;//异常模块
	private String addr;//异常文件地址
	private String msg;//异常原因
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public SMSEntity(String date, String model, String addr, String msg) {
		super();
		this.date = date;
		this.model = model;
		this.addr = addr;
		this.msg = msg;
	}
	
	public SMSEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "SMSEntity [date=" + date + ", model=" + model + ", addr=" + addr + ", msg=" + msg + "]";
	}
	
}
