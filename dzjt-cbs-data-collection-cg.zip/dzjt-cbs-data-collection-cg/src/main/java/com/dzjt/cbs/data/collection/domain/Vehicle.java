package com.dzjt.cbs.data.collection.domain;

import java.util.Date;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午1:22:05
 */
public class Vehicle {
	private Integer id;//
	private Integer version;//
	private Integer enabled;//
	private String license;//
	private String frameNo;//
	private String engineNo;//
	private Date productDate;//
	private Date purchaseDate;//
	private Date startDate;//
	private Date licenseDate;//
	private Date retireDate;//
	private String operatingNo;//
	private String fromCompany;//
	private Integer hasRight;//
	private Double usageAgeLimit;//
	private Double depreciationAgeLimit;//
	private Integer vehicleStatus;//
	private Integer vehicleAssetId;//
	private Integer obtainWayId;//
	private Integer usageId;//
	private Integer vehicleColorId;//
	private Integer ownerId;//
	private Integer assetOwnerId;//
	private Integer vehicleCategoryId;//
	private Integer areaId;//
	private Integer ownOrganizationId;//
	private Integer usageOrganizationId;//
	private Integer supplierId;//
	private Integer vehicleModelId;//
	private Integer operateTypeId;//
	private Integer contractTypeId;//
	private Integer operationCategoryId;//
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}
	
	public Integer getEnabled() {
		return enabled;
	}
	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}
	public String getLicense() {
		return license;
	}
	public void setLicense(String license) {
		this.license = license;
	}
	public String getFrameNo() {
		return frameNo;
	}
	public void setFrameNo(String frameNo) {
		this.frameNo = frameNo;
	}
	public String getEngineNo() {
		return engineNo;
	}
	public void setEngineNo(String engineNo) {
		this.engineNo = engineNo;
	}
	public Date getProductDate() {
		return productDate;
	}
	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}
	public Date getPurchaseDate() {
		return purchaseDate;
	}
	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getLicenseDate() {
		return licenseDate;
	}
	public void setLicenseDate(Date licenseDate) {
		this.licenseDate = licenseDate;
	}
	public Date getRetireDate() {
		return retireDate;
	}
	public void setRetireDate(Date retireDate) {
		this.retireDate = retireDate;
	}
	public String getOperatingNo() {
		return operatingNo;
	}
	public void setOperatingNo(String operatingNo) {
		this.operatingNo = operatingNo;
	}
	public String getFromCompany() {
		return fromCompany;
	}
	public void setFromCompany(String fromCompany) {
		this.fromCompany = fromCompany;
	}

	public Integer getHasRight() {
		return hasRight;
	}
	public void setHasRight(Integer hasRight) {
		this.hasRight = hasRight;
	}
	public Double getUsageAgeLimit() {
		return usageAgeLimit;
	}
	public void setUsageAgeLimit(Double usageAgeLimit) {
		this.usageAgeLimit = usageAgeLimit;
	}
	public Double getDepreciationAgeLimit() {
		return depreciationAgeLimit;
	}
	public void setDepreciationAgeLimit(Double depreciationAgeLimit) {
		this.depreciationAgeLimit = depreciationAgeLimit;
	}
	public Integer getVehicleStatus() {
		return vehicleStatus;
	}
	public void setVehicleStatus(Integer vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}
	public Integer getVehicleAssetId() {
		return vehicleAssetId;
	}
	public void setVehicleAssetId(Integer vehicleAssetId) {
		this.vehicleAssetId = vehicleAssetId;
	}
	public Integer getObtainWayId() {
		return obtainWayId;
	}
	public void setObtainWayId(Integer obtainWayId) {
		this.obtainWayId = obtainWayId;
	}
	public Integer getUsageId() {
		return usageId;
	}
	public void setUsageId(Integer usageId) {
		this.usageId = usageId;
	}
	public Integer getVehicleColorId() {
		return vehicleColorId;
	}
	public void setVehicleColorId(Integer vehicleColorId) {
		this.vehicleColorId = vehicleColorId;
	}
	public Integer getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(Integer ownerId) {
		this.ownerId = ownerId;
	}
	public Integer getAssetOwnerId() {
		return assetOwnerId;
	}
	public void setAssetOwnerId(Integer assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}
	public Integer getVehicleCategoryId() {
		return vehicleCategoryId;
	}
	public void setVehicleCategoryId(Integer vehicleCategoryId) {
		this.vehicleCategoryId = vehicleCategoryId;
	}
	public Integer getAreaId() {
		return areaId;
	}
	public void setAreaId(Integer areaId) {
		this.areaId = areaId;
	}
	public Integer getOwnOrganizationId() {
		return ownOrganizationId;
	}
	public void setOwnOrganizationId(Integer ownOrganizationId) {
		this.ownOrganizationId = ownOrganizationId;
	}
	public Integer getUsageOrganizationId() {
		return usageOrganizationId;
	}
	public void setUsageOrganizationId(Integer usageOrganizationId) {
		this.usageOrganizationId = usageOrganizationId;
	}
	public Integer getSupplierId() {
		return supplierId;
	}
	public void setSupplierId(Integer supplierId) {
		this.supplierId = supplierId;
	}
	public Integer getVehicleModelId() {
		return vehicleModelId;
	}
	public void setVehicleModelId(Integer vehicleModelId) {
		this.vehicleModelId = vehicleModelId;
	}
	public Integer getOperateTypeId() {
		return operateTypeId;
	}
	public void setOperateTypeId(Integer operateTypeId) {
		this.operateTypeId = operateTypeId;
	}
	public Integer getContractTypeId() {
		return contractTypeId;
	}
	public void setContractTypeId(Integer contractTypeId) {
		this.contractTypeId = contractTypeId;
	}
	public Integer getOperationCategoryId() {
		return operationCategoryId;
	}
	public void setOperationCategoryId(Integer operationCategoryId) {
		this.operationCategoryId = operationCategoryId;
	}

}
