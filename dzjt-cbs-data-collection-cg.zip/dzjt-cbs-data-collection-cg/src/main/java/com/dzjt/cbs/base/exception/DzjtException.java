package com.dzjt.cbs.base.exception;

public class DzjtException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2896268743031386224L;
	private String errorMessage;
	
	public DzjtException(String errorMessage) {
		// TODO Auto-generated constructor stub
		this.errorMessage = errorMessage;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	@Override
	public String toString() {
		return errorMessage + '\'';
	}
}
