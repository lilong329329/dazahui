package com.dzjt.cbs.data.collection.dto.Data;



import io.swagger.annotations.ApiModelProperty;

public class DataListOutDTO {
	/**
	 * 
	 */
	private static final long serialVersionUID = -9200463695171361162L;
	private DataListInfo value;
	
	@ApiModelProperty(value = "value")
	public DataListInfo getValue() {
		return value;
	}

	public void setValue(DataListInfo value) {
		this.value = value;
	}
	
}
