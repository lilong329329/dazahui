package com.dzjt.cbs.data.collection.infrastructure;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

import com.dzjt.cbs.data.collection.domain.Vehicle;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午2:36:06
 */
@Mapper
public interface VehicleMapper {
	@Select("SELECT * FROM vms.Vehicle")
	@Results({ @Result(column = "Id", property = "id"), 
		@Result(column = "Version", property = "version"),
			@Result(column = "Enabled", property = "enabled"), 
			@Result(column = "License", property = "license"),
			@Result(column = "FrameNo", property = "frameNo"), 
			@Result(column = "EngineNo", property = "engineNo"),
			@Result(column = "ProductDate", property = "productDate"),
			@Result(column = "PurchaseDate", property = "purchaseDate"),
			@Result(column = "StartDate", property = "startDate"),
			@Result(column = "LicenseDate", property = "licenseDate"),
			@Result(column = "RetireDate", property = "retireDate"),
			@Result(column = "OperatingNo", property = "operatingNo"),
			@Result(column = "FromCompany", property = "fromCompany"),
			@Result(column = "HasRight", property = "hasRight"),
			@Result(column = "UsageAgeLimit", property = "usageAgeLimit"),
			@Result(column = "DepreciationAgeLimit", property = "depreciationAgeLimit"),
			@Result(column = "VehicleStatus", property = "vehicleStatus"),

			@Result(column = "VehicleAssetId", property = "vehicleAssetId"),
			@Result(column = "ObtainWayId", property = "obtainWayId"),
			@Result(column = "UsageId", property = "usageId"),
			@Result(column = "VehicleColorId", property = "vehicleColorId"),
			@Result(column = "OwnerId", property = "ownerId"),
			@Result(column = "AssetOwnerId", property = "assetOwnerId"),
			@Result(column = "VehicleCategoryId", property = "vehicleCategoryId"),
			@Result(column = "AreaId", property = "areaId"),
			@Result(column = "OwnOrganizationId", property = "ownOrganizationId"),
			@Result(column = "UsageOrganizationId", property = "usageOrganizationId"),
			@Result(column = "SupplierId", property = "supplierId"),
			@Result(column = "VehicleModelId", property = "vehicleModelId"),
			@Result(column = "OperateTypeId", property = "operateTypeId"),
			@Result(column = "ContractTypeId", property = "contractTypeId"),
			@Result(column = "OperationCategoryId", property = "operationCategoryId") })
	List<Vehicle> findAll();
	@Select("SELECT *  FROM vms.Vehicle  where Convert(varchar,productdate,120)  like #{time1} OR CONVERT (VARCHAR,StartDate,120) LIKE #{time1}")
	List<Vehicle> findbyIncrement(String time1);

	@Select("SELECT COUNT(1) FROM vms.Vehicle")
	int findAllByCount();
}
