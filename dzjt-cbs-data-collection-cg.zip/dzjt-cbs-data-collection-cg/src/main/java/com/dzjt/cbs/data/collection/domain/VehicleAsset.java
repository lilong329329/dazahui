package com.dzjt.cbs.data.collection.domain;

/**
 * @author 作者 E-mail:lilong
 * @version 创建时间：2017年12月18日 下午1:27:36
 */
public class VehicleAsset {
	private Integer id;//
	private Integer version;//
	private Integer enabled;//
	private Double purchasePrice;//
	private Double purchaseTax;//
	private Double licensePrice;//
	private Double licenseOtherPrice;//
	private Double upholsterPrice;//
	private Double totalPrice;//
	private Double remainPrice;//
	private Double secondHandPrice;//
	private Integer vehicleId;//
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getVersion() {
		return version;
	}
	public void setVersion(Integer version) {
		this.version = version;
	}

	public Integer getEnabled() {
		return enabled;
	}
	public void setEnabled(Integer enabled) {
		this.enabled = enabled;
	}
	public Double getPurchasePrice() {
		return purchasePrice;
	}
	public void setPurchasePrice(Double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}
	public Double getPurchaseTax() {
		return purchaseTax;
	}
	public void setPurchaseTax(Double purchaseTax) {
		this.purchaseTax = purchaseTax;
	}
	public Double getLicensePrice() {
		return licensePrice;
	}
	public void setLicensePrice(Double licensePrice) {
		this.licensePrice = licensePrice;
	}
	public Double getLicenseOtherPrice() {
		return licenseOtherPrice;
	}
	public void setLicenseOtherPrice(Double licenseOtherPrice) {
		this.licenseOtherPrice = licenseOtherPrice;
	}
	public Double getUpholsterPrice() {
		return upholsterPrice;
	}
	public void setUpholsterPrice(Double upholsterPrice) {
		this.upholsterPrice = upholsterPrice;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Double getRemainPrice() {
		return remainPrice;
	}
	public void setRemainPrice(Double remainPrice) {
		this.remainPrice = remainPrice;
	}
	public Double getSecondHandPrice() {
		return secondHandPrice;
	}
	public void setSecondHandPrice(Double secondHandPrice) {
		this.secondHandPrice = secondHandPrice;
	}
	public Integer getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(Integer vehicleId) {
		this.vehicleId = vehicleId;
	}

}
