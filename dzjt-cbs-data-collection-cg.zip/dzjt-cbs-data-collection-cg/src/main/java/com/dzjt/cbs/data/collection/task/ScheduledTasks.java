package com.dzjt.cbs.data.collection.task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.dzjt.cbs.base.exception.DzjtException;
import com.dzjt.cbs.data.collection.service.CgDataMigrationService;

@Component
@Configurable
public class ScheduledTasks{
	@Autowired
	private CgDataMigrationService dataMigrationService;
 
	
	  /**表示查询所有的数据实现
	 * @throws DzjtException
	 */
	@Scheduled(cron = "0 50 14 * * ?")
	public void cgDataMigrationALL() throws DzjtException{
	    	try {
				dataMigrationService.cgDataMigrationALL();
			} catch (Exception e) {
				
				throw new DzjtException("车管迁移全量执行失败:" + e.getMessage());
			}
	    }
	  
	//每月取全量数据库   "0 0 0 0 1/1 ? *"
    @Scheduled(cron = "0 0 0 1 * ?")
    public void CgFindDataByMonth() throws DzjtException{
    	try {
			dataMigrationService.cgFindDataByMonth();
		} catch (Exception e) {
			
			throw new DzjtException("车管迁移全量执行失败:" + e.getMessage());
		}
    }
    
}
